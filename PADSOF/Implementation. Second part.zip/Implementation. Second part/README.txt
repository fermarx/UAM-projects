Administrator information:
	-Nickname: Juan
	-Password: uameps
	
We have created some projects, groups and users, so you can already start the application with some information. Also, you can star from 0 deleting the "system.ser" file.
The users that the system has in the current "system.ser" file are:

Users:
	- Nickname: Angel
	- Password: a
	
	- Nickname: Jorge
	- Password: j
	
	- Nickname: Xiao
	- Password: x
	
	- Nickname: Banned (Banned user)
	- Password: b
	
Groups:
	-Videogames
		Manager: Angel
		Joined users: Xiao
		
	-Zelda, Subgroup of Videogames
		Manager: Angel
		Joined users: Jorge
	
Projects:
	-Bridge
		Proponent: Xiao
		Voters as individuals:
		Voters as group: Zelda
		
	-Quarantine
		Proponent: Jorge
		Voters as individuals:
		Voters as group:
	
	-Meetings to play
		Proponent: Zelda
		Voters as individuals: Xiao, Jorge
		Voters as group:
	
	-Regional Dances
		Proponent: Xiao (Pending project)
		Voters as individuals:
		Voters as group:
